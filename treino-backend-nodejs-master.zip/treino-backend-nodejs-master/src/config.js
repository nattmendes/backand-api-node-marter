// Server config 
export const SERVER = {
  PORT: 3100
}

// Database config
export const DB = {
  HOST: "localhost",
  USER: "root",
  PASS: "",
  DB_NAME: "apinode"
}