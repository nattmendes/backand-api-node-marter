# Node API with Express

## Second Commit

```javascript
const teste = () => {
  console.log("olá")
}
```